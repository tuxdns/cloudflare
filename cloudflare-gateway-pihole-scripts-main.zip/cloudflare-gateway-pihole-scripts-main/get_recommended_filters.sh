#!/bin/bash

node download_lists.js blocklist
